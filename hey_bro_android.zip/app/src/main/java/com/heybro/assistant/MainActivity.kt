package com.heybro.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.net.URLEncoder
import java.util.Locale

class MainActivity : Activity() {
    private var sr: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var btn: Button
    private val h = Handler(Looper.getMainLooper())
    private var running = false
    private var armedUntil = 0L

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        tts = TextToSpeech(this) { tts.language = Locale.US }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40) }
        root.addView(TextView(this).apply { text = "🎙️ Hey Bro"; textSize = 28f })
        root.addView(TextView(this).apply { text = "Say: hey bro open youtube / search lofi on youtube / message 919876543210 saying hi" })
        btn = Button(this).apply { text = "Start listening"; setOnClickListener { toggle() } }
        root.addView(btn)
        logView = TextView(this).apply { textSize = 16f }
        scroll = ScrollView(this).apply { addView(logView) }
        root.addView(scroll)
        setContentView(root)
    }

    private fun log(s: String) { logView.append(s + "\n"); scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) } }
    private fun say(s: String) { log("🤖 $s"); tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "hb") }

    private fun toggle() {
        if (running) { running = false; sr?.destroy(); sr = null; btn.text = "Start listening"; return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1); return
        }
        running = true; btn.text = "Stop listening"; log("Listening for “hey bro”…")
        sr = SpeechRecognizer.createSpeechRecognizer(this).apply { setRecognitionListener(listener) }
        listen()
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        if (r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) toggle() else log("Microphone permission is needed.")
    }

    private fun listen() {
        if (!running) return
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
        try { sr?.startListening(i) } catch (e: Exception) { h.postDelayed({ listen() }, 1000) }
    }

    private val listener = object : RecognitionListener {
        override fun onResults(r: android.os.Bundle?) {
            val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.lowercase() ?: ""
            val k = t.indexOf("hey bro")
            if (k >= 0) {
                val cmd = t.substring(k + 7).trim()
                if (cmd.isNotEmpty()) handle(cmd) else { armedUntil = System.currentTimeMillis() + 8000; say("Yes?") }
            } else if (System.currentTimeMillis() < armedUntil && t.isNotEmpty()) { armedUntil = 0; handle(t) }
            h.postDelayed({ listen() }, 700)
        }
        override fun onError(e: Int) { h.postDelayed({ listen() }, 700) }
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(p: Bundle?) {}
        override fun onEvent(t: Int, p: Bundle?) {}
    }

    private fun go(i: Intent) { try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { say("I couldn’t open that.") } }
    private fun url(u: String) = go(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun handle(raw: String) {
        val cmd = raw.replace(Regex("[.,!?]"), "").trim(); log("🗣️ $cmd")
        Regex("(?:send )?(?:whatsapp )?(?:message|msg|text) (?:to )?([\\d +]+) (?:saying|that|says) (.+)").find(cmd)?.let {
            val num = it.groupValues[1].filter(Char::isDigit)
            url("https://wa.me/$num?text=${enc(it.groupValues[2])}"); say("WhatsApp is ready. Tap send to confirm."); return
        }
        (Regex("(?:search|find|play) (.+?) (?:on|in) youtube").find(cmd) ?: Regex("^play (.+)").find(cmd))?.let {
            val q = it.groupValues[1]
            go(Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", q))
            say("Searching YouTube for $q"); return
        }
        Regex("(?:search|google) (?:for )?(.+)").find(cmd)?.let { url("https://www.google.com/search?q=${enc(it.groupValues[1])}"); say("Searching ${it.groupValues[1]}"); return }
        Regex("open (.+)").find(cmd)?.let {
            val name = it.groupValues[1].removeSuffix(" app").trim()
            val pm = packageManager
            val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            val hit = apps.firstOrNull { a -> a.loadLabel(pm).toString().lowercase() == name }
                ?: apps.firstOrNull { a -> a.loadLabel(pm).toString().lowercase().contains(name) }
            val li = hit?.let { a -> pm.getLaunchIntentForPackage(a.activityInfo.packageName) }
            if (li != null) { go(li); say("Opening $name") } else { url("https://www.google.com/search?q=${enc(name)}"); say("Searching for $name") }
            return
        }
        say("Sorry, I didn’t get that.")
    }

    override fun onDestroy() { running = false; sr?.destroy(); tts.shutdown(); super.onDestroy() }
}
